# cli-tool-test
Testing a generic CLI tool that can be installed with Homebrew
