# Changelog

## [0.2.1](https://github.com/unfrgivn/cli-tool-test/compare/v0.2.0...v0.2.1) (2024-07-07)


### Bug Fixes

* testing fix commit ([8cca654](https://github.com/unfrgivn/cli-tool-test/commit/8cca6545b42e4f6d2b94a0920ce28c232e38f359))

## [0.2.0](https://github.com/unfrgivn/cli-tool-test/compare/v0.1.0...v0.2.0) (2024-07-07)


### Features

* testing feat commit ([a9f261b](https://github.com/unfrgivn/cli-tool-test/commit/a9f261b7392c2624682b7d89630ec4f2b2290956))
